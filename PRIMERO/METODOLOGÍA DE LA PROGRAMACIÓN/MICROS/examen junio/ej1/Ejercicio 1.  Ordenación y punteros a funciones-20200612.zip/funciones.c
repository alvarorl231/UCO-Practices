/*------------------------------------------------------------------*/
/* NOMBRE Y APELLIDOS:                                              */
/* DNI:                                                             */
/*------------------------------------------------------------------*/

#include "funciones.h"

//HAZ AQUI LOS INCLUDE QUE SEAN NECESARIOS


/*------------------------------------------------------------------*/
/*Ejercicio 1: Ordenacion y punteros a funciones
               nEle: n�mero de elementos del vector
               Vector: el vector a ordenar
               criterio: 0-->ascendente por indice de masa corporal
                         1-->descendente por nombre 
/*------------------------------------------------------------------*/
void ejercicio1(int nEle, struct datos* Vector, int criterio)
{

     if(criterio==0) 
     {
         //INCLUYE AQUI LA LLAMADA A TU FUNCI�N DE ORDENACI�N PARA ORDEN ASCENDENTE
        
                       
     }
     else 
     {
         //INCLUYE AQUI LA LLAMADA A TU FUNCI�N DE ORDENACI�N PARA ORDEN DESCENDENTE
                     
     }
}

//ESCRIBE AQU� TU FUNCION DE ORDENACI�N Y TODAS LAS FUNCIONES QUE CONSIDERES NECESARIAS
